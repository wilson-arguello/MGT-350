/**
 * @(#)Menu.java
 *
 *
 * @Jorge Ahias Calvo 
 * @version 1.00 20/junio/2013
 */
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class Menu extends JFrame {
    private JLabel label1;
    public String arregloOpciones[] = {"1-Solicitar Datos", "2-Calcular Area"};
    private JComboBox comboBox1 = new JComboBox(arregloOpciones);
    private JButton JButton1;
    public static Ventana1 objetovent1;
	Area objetoArea = new Area();
	Menu (){
	   super("Menu Principal");
	}

 public void ejecutarPrueba(){
		setLayout( new FlowLayout() ); // set frame layout
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setSize(300, 300);
        label1 = new JLabel("Seleccione una Opci�n");
        add(label1);

        comboBox1.setMaximumRowCount(arregloOpciones.length);
        add(comboBox1);

        JButton1 = new JButton("Ejecutar Opci�n");
        add(JButton1);

        ListenerBoton listenerBoton = new ListenerBoton();
        JButton1.addActionListener(listenerBoton);
   }
     public class ListenerBoton implements ActionListener {

        public void actionPerformed(ActionEvent e) {
            //Aqui se decide que reporte mostrar segun respuesta del usuario al presionar en el boton ver.
            int selectedIndex = comboBox1.getSelectedIndex();

            objetovent1 = new Ventana1(objetoArea);

            switch (selectedIndex) {
                case 0:
                    objetovent1.setVisible(true);
                    EjecutarMenu.objetoMenu.setVisible( false );
                    break;
                case 1:
                    EjecutarMenu.objetoMenu.setVisible( true );
     			 	JOptionPane.showMessageDialog(null, "Calculo Area="+objetoArea.calcularArea(), "",JOptionPane.PLAIN_MESSAGE);
                    break;
            }

        }

 } // end main

    
}