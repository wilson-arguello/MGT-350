/**
 * @(#)Area.java
 * *
 * @author Jorge Ah�as Calvo
 * @version 1.00 20/junio/2013
 */
public class Area {
   private int largo;
   private int ancho;
    public Area() {
    }
    public int calcularArea(){
    	return largo*ancho;
    }
    public void setLargo(int largo){
    	this.largo=largo;
    }
    public void setAncho(int ancho){
    	this.ancho=ancho;
    }
    public int getLargo(){
    	return largo;
    }
    public int getAncho(){
    	return ancho;
    }

}