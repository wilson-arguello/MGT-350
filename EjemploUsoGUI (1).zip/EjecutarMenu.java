public class EjecutarMenu 
 {
 public static Menu objetoMenu;
 public static void main( String args[] ) { 
 	objetoMenu = new Menu();
 	objetoMenu.ejecutarPrueba();
 	objetoMenu.setVisible(true);
 }
} // end class EjecutarMenu