 import java.awt.FlowLayout; 
 import javax.swing.*;
 import java.awt.event.*;

 public class Ventana1 extends JFrame{
 private JLabel label1;
 private JButton botonLimpiar; 
 private JButton botonSalir; 
 private ButtonGroup btnGroup = new ButtonGroup();
 JTextField valor1 = new JTextField(3);
 JTextField valor2 = new JTextField(3);
 Area objetolocal = new Area();
 public Ventana1(){
 } 
 public Ventana1(Area objetoArea){

 super( "Ingresar Datos" );
 objetolocal = objetoArea;
 setLayout( new FlowLayout() ); // set frame layout
 this.setSize( 275, 200 ); 
 this.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );

 valor1.setText("0");
 valor1.setEditable(true);
 add(valor1);
 valor2.setText("0");
 valor2.setEditable(true);
 add(valor2);
 botonLimpiar = new JButton ("Limpiar"); 
 add (botonLimpiar);
 botonSalir = new JButton ("Salir"); 
 add(botonSalir);
 //Registrar manejador de eventos button
 ManejadorBoton listener = new ManejadorBoton();
 botonSalir.addActionListener(listener);
 botonLimpiar.addActionListener(listener);
 }
  class ManejadorBoton implements ActionListener {
  		
		 public void actionPerformed(ActionEvent e) {
			 if (e.getSource() == botonSalir){
			 	 objetolocal.setAncho(Integer.parseInt(valor1.getText()));
			 	 objetolocal.setLargo(Integer.parseInt(valor2.getText()));
			 	 Menu.objetovent1.setVisible(false);
			 	 EjecutarMenu.objetoMenu.setVisible( true );
			 }
			if (e.getSource() == botonLimpiar){
				valor1.setText("0");
				valor2.setText("0");
			}

		 }
	 }

 }// end class Ventana